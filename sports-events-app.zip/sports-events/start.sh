#!/bin/bash
echo "🏆 SportsPulse - Sports Event Recommendation App"
echo "================================================"

# Install backend deps
echo ""
echo "📦 Installing backend dependencies..."
cd backend && npm install
cd ..

# Install frontend deps
echo ""
echo "📦 Installing frontend dependencies..."
cd frontend && npm install
cd ..

echo ""
echo "✅ All dependencies installed!"
echo ""
echo "🚀 Starting servers..."
echo "   Backend  → http://localhost:5000"
echo "   Frontend → http://localhost:3000"
echo ""

# Start backend in background
cd backend && node server.js &
BACKEND_PID=$!

# Start frontend
cd ../frontend && npm start

# Cleanup on exit
trap "kill $BACKEND_PID" EXIT
