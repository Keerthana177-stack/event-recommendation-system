import React, { useState } from 'react';
import './Header.css';

function SignInModal({ onClose }) {
  const [mode, setMode] = useState('signin'); // 'signin' | 'signup'
  const [form, setForm] = useState({ name: '', email: '', password: '' });
  const [loggedIn, setLoggedIn] = useState(false);
  const [user, setUser] = useState(null);
  const [error, setError] = useState('');

  const handleSubmit = () => {
    setError('');
    if (!form.email || !form.password) { setError('Please fill in all fields.'); return; }
    if (mode === 'signup' && !form.name) { setError('Name is required.'); return; }
    if (form.password.length < 4) { setError('Password must be at least 4 characters.'); return; }
    // Simulate auth (local only)
    const storedUsers = JSON.parse(localStorage.getItem('sp_users') || '[]');
    if (mode === 'signup') {
      if (storedUsers.find(u => u.email === form.email)) { setError('Email already registered.'); return; }
      const newUser = { name: form.name, email: form.email, password: form.password };
      localStorage.setItem('sp_users', JSON.stringify([...storedUsers, newUser]));
      localStorage.setItem('sp_current', JSON.stringify(newUser));
      setUser(newUser); setLoggedIn(true);
    } else {
      const found = storedUsers.find(u => u.email === form.email && u.password === form.password);
      if (!found) { setError('Invalid email or password.'); return; }
      localStorage.setItem('sp_current', JSON.stringify(found));
      setUser(found); setLoggedIn(true);
    }
  };

  if (loggedIn) return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal-box signin-modal" onClick={e => e.stopPropagation()}>
        <div className="si-success">
          <div className="si-avatar">{user.name ? user.name[0].toUpperCase() : '👤'}</div>
          <h3>Welcome, {user.name || user.email}! 🎉</h3>
          <p>You're signed in successfully.</p>
          <button className="btn btn-primary" style={{width:'100%', marginTop:8}} onClick={onClose}>
            Continue to App
          </button>
          <button className="btn btn-outline btn-sm" style={{width:'100%'}} onClick={() => {
            localStorage.removeItem('sp_current'); onClose();
          }}>Sign Out</button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal-box signin-modal" onClick={e => e.stopPropagation()}>
        <div className="si-header">
          <span className="si-logo">⚡</span>
          <h3>{mode === 'signin' ? 'Welcome Back' : 'Create Account'}</h3>
          <p>{mode === 'signin' ? 'Sign in to book your favourite events' : 'Join SportsPulse today'}</p>
        </div>
        <div className="si-body">
          <div className="si-tabs">
            <button className={mode === 'signin' ? 'active' : ''} onClick={() => { setMode('signin'); setError(''); }}>Sign In</button>
            <button className={mode === 'signup' ? 'active' : ''} onClick={() => { setMode('signup'); setError(''); }}>Sign Up</button>
          </div>
          {mode === 'signup' && (
            <div className="bm-field">
              <label>Full Name</label>
              <input className="input" placeholder="Your name"
                value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} />
            </div>
          )}
          <div className="bm-field">
            <label>Email Address</label>
            <input className="input" type="email" placeholder="you@example.com"
              value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} />
          </div>
          <div className="bm-field">
            <label>Password</label>
            <input className="input" type="password" placeholder="••••••••"
              value={form.password} onChange={e => setForm(f => ({ ...f, password: e.target.value }))}
              onKeyDown={e => e.key === 'Enter' && handleSubmit()} />
          </div>
          {error && <div className="si-error">⚠️ {error}</div>}
          <button className="btn btn-primary" style={{ width: '100%', padding: '12px' }} onClick={handleSubmit}>
            {mode === 'signin' ? '🔐 Sign In' : '🚀 Create Account'}
          </button>
          <button className="btn btn-outline btn-sm" style={{ width: '100%' }} onClick={onClose}>Cancel</button>
        </div>
      </div>
    </div>
  );
}

export default function Header({ onSearch }) {
  const [q, setQ] = useState('');
  const [showSignIn, setShowSignIn] = useState(false);

  const currentUser = (() => { try { return JSON.parse(localStorage.getItem('sp_current')); } catch { return null; } })();

  const handleSearch = (e) => {
    const val = e.target.value;
    setQ(val);
    onSearch(val);
  };

  const handleSignOut = () => {
    localStorage.removeItem('sp_current');
    window.location.reload();
  };

  return (
    <>
      <header className="header">
        <div className="container header-inner">
          <div className="logo">
            <span className="logo-icon">⚡</span>
            <span className="logo-text">SPORTS<em>PULSE</em></span>
          </div>

          <div className="search-wrap">
            <span className="search-icon">🔍</span>
            <input
              className="search-input"
              type="text"
              placeholder="Search events, sports, cities…"
              value={q}
              onChange={handleSearch}
            />
            {q && <button className="search-clear" onClick={() => { setQ(''); onSearch(''); }}>✕</button>}
          </div>

          <nav className="header-nav">
            <a href="#events">Events</a>
            <a href="#featured">Featured</a>
            {currentUser ? (
              <div className="user-pill">
                <span className="user-avatar">{currentUser.name ? currentUser.name[0].toUpperCase() : '👤'}</span>
                <span className="user-name">{currentUser.name || currentUser.email.split('@')[0]}</span>
                <button className="btn btn-outline btn-sm" onClick={handleSignOut}>Sign Out</button>
              </div>
            ) : (
              <button className="btn btn-primary btn-sm" onClick={() => setShowSignIn(true)}>Sign In</button>
            )}
          </nav>
        </div>
      </header>
      {showSignIn && <SignInModal onClose={() => setShowSignIn(false)} />}
    </>
  );
}
