import React, { useEffect } from 'react';
import './EventModal.css';

const SPORT_COLORS = {
  Cricket: '#ff4d00', Football: '#00c853', Kabaddi: '#ffb400',
  Basketball: '#ff6d00', Tennis: '#00e5ff', Badminton: '#d500f9', Wrestling: '#f44336'
};

function Stars({ rating }) {
  return <span className="stars">{'★'.repeat(Math.floor(rating))}{rating % 1 ? '½' : ''} {rating}</span>;
}

export default function EventModal({ event, onClose, onBook }) {
  useEffect(() => {
    const handler = (e) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', handler);
    document.body.style.overflow = 'hidden';
    return () => { window.removeEventListener('keydown', handler); document.body.style.overflow = ''; };
  }, [onClose]);

  const color = SPORT_COLORS[event.sport] || '#ff4d00';
  const avail = event.seats - event.bookedSeats;
  const pct = Math.round((event.bookedSeats / event.seats) * 100);
  const dateObj = new Date(event.date);
  const formattedDate = dateObj.toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal-box event-modal" onClick={e => e.stopPropagation()}>
        {/* Header image */}
        <div className="em-hero">
          <img src={event.image} alt={event.title} className="em-hero-img" />
          <div className="em-hero-overlay" />
          <button className="em-close" onClick={onClose}>✕</button>
          <div className="em-hero-content">
            <span className="badge" style={{ background: color + 'dd', color: 'white' }}>{event.sport}</span>
            {event.featured && <span className="badge badge-gold">★ Featured</span>}
            <h2 className="em-title">{event.title}</h2>
          </div>
        </div>

        {/* Body */}
        <div className="em-body">
          <div className="em-info-grid">
            <div className="em-info-item">
              <span className="em-info-label">📅 Date</span>
              <span>{formattedDate}</span>
            </div>
            <div className="em-info-item">
              <span className="em-info-label">🕐 Time</span>
              <span>{event.time}</span>
            </div>
            <div className="em-info-item">
              <span className="em-info-label">📍 Venue</span>
              <span>{event.venue}</span>
            </div>
            <div className="em-info-item">
              <span className="em-info-label">🏙 City</span>
              <span>{event.city}, {event.country}</span>
            </div>
            <div className="em-info-item">
              <span className="em-info-label">🏷 Category</span>
              <span>{event.category}</span>
            </div>
            <div className="em-info-item">
              <span className="em-info-label">⭐ Rating</span>
              <Stars rating={event.rating} />
            </div>
          </div>

          <div className="em-desc">
            <h4>About this event</h4>
            <p>{event.description}</p>
          </div>

          <div className="em-tags">
            {event.tags.map(t => <span key={t} className="tag">{t}</span>)}
          </div>

          <div className="em-avail">
            <div className="em-avail-top">
              <span>Seat Availability</span>
              <span style={{ color: avail < 30 ? '#f44336' : 'var(--success)' }}>
                {avail} / {event.seats} available
              </span>
            </div>
            <div className="avail-bar">
              <div className="avail-bar-fill"
                style={{ width: pct + '%', background: pct > 85 ? '#f44336' : pct > 60 ? '#ffb400' : '#00c853' }} />
            </div>
          </div>

          <div className="em-footer">
            <div>
              <div style={{ fontSize: 11, textTransform: 'uppercase', letterSpacing: 1, color: 'var(--muted)' }}>Price per ticket</div>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: 36, color: 'var(--accent)' }}>
                ₹{event.price.toLocaleString()}
              </div>
            </div>
            <div style={{ display: 'flex', gap: 10 }}>
              <button className="btn btn-outline" onClick={onClose}>Close</button>
              <button className="btn btn-primary btn-lg" onClick={() => onBook(event)}
                disabled={avail === 0}>
                {avail === 0 ? 'Sold Out' : 'Book Tickets'}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
