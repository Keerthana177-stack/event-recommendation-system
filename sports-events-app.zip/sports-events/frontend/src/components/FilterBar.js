import React, { useState } from 'react';
import './FilterBar.css';

const SORT_OPTIONS = [
  { value: 'date_asc', label: '📅 Upcoming First' },
  { value: 'price_asc', label: '💰 Price: Low–High' },
  { value: 'price_desc', label: '💰 Price: High–Low' },
  { value: 'rating', label: '⭐ Top Rated' },
];

export default function FilterBar({ filters, activeFilters, onFilterChange, onReset, view, onViewChange, count }) {
  const [showAdvanced, setShowAdvanced] = useState(false);
  const isFiltered = activeFilters.sport !== 'All' || activeFilters.city !== 'All' ||
    activeFilters.category !== 'All' || activeFilters.minPrice || activeFilters.maxPrice;

  return (
    <div className="filterbar" id="events">
      <div className="filterbar-top">
        <div className="filter-chips">
          {/* Sport filter */}
          <div className="filter-group">
            <label>Sport</label>
            <div className="chip-row">
              {filters.sports.map(s => (
                <button
                  key={s}
                  className={`tag ${activeFilters.sport === s ? 'active' : ''}`}
                  onClick={() => onFilterChange('sport', s)}
                >{s}</button>
              ))}
            </div>
          </div>
        </div>

        <div className="filterbar-right">
          <button className="btn btn-outline btn-sm" onClick={() => setShowAdvanced(v => !v)}>
            {showAdvanced ? '▲' : '▼'} Filters {isFiltered && <span className="filter-dot" />}
          </button>
          <div className="view-toggle">
            <button className={view === 'grid' ? 'active' : ''} onClick={() => onViewChange('grid')}>⊞</button>
            <button className={view === 'list' ? 'active' : ''} onClick={() => onViewChange('list')}>☰</button>
          </div>
          <select className="select" style={{ width: 'auto' }}
            value={activeFilters.sortBy}
            onChange={e => onFilterChange('sortBy', e.target.value)}
          >
            {SORT_OPTIONS.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
          </select>
        </div>
      </div>

      {showAdvanced && (
        <div className="filterbar-advanced">
          <div className="adv-row">
            <div className="adv-col">
              <label>City</label>
              <select className="select" value={activeFilters.city} onChange={e => onFilterChange('city', e.target.value)}>
                {filters.cities.map(c => <option key={c}>{c}</option>)}
              </select>
            </div>
            <div className="adv-col">
              <label>Category</label>
              <select className="select" value={activeFilters.category} onChange={e => onFilterChange('category', e.target.value)}>
                {filters.categories.map(c => <option key={c}>{c}</option>)}
              </select>
            </div>
            <div className="adv-col">
              <label>Min Price (₹)</label>
              <input className="input" type="number" placeholder="0" value={activeFilters.minPrice}
                onChange={e => onFilterChange('minPrice', e.target.value)} />
            </div>
            <div className="adv-col">
              <label>Max Price (₹)</label>
              <input className="input" type="number" placeholder="Any" value={activeFilters.maxPrice}
                onChange={e => onFilterChange('maxPrice', e.target.value)} />
            </div>
            {isFiltered && (
              <button className="btn btn-outline btn-sm" onClick={onReset} style={{ alignSelf: 'flex-end' }}>
                ✕ Reset
              </button>
            )}
          </div>
        </div>
      )}

      <div className="filterbar-result">
        <span className="result-count">{count} events found</span>
      </div>
    </div>
  );
}
