import React from 'react';
import './StatsBar.css';

const ICONS = { Cricket: '🏏', Football: '⚽', Kabaddi: '🤼', Basketball: '🏀', Tennis: '🎾', Badminton: '🏸', Wrestling: '🥊' };

export default function StatsBar({ stats }) {
  if (!stats) return null;
  return (
    <div className="statsbar">
      <div className="container statsbar-inner">
        <span className="statsbar-label">Sports Available</span>
        <div className="statsbar-sports">
          {Object.entries(stats.sportBreakdown).map(([sport, count]) => (
            <div className="statsbar-sport" key={sport}>
              <span>{ICONS[sport] || '🏆'}</span>
              <span>{sport}</span>
              <span className="statsbar-count">{count}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
