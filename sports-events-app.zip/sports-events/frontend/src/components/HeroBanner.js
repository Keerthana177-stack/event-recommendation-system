import React from 'react';
import './HeroBanner.css';

export default function HeroBanner({ stats }) {
  return (
    <section className="hero">
      <div className="hero-bg">
        <div className="hero-orb orb1" />
        <div className="hero-orb orb2" />
        <div className="hero-grid" />
      </div>
      <div className="container hero-inner">
        <div className="hero-label badge badge-accent">🔴 Live Events Available</div>
        <h1 className="hero-title">
          Your Ultimate<br />
          <span className="hero-accent">Sports Event</span><br />
          Companion
        </h1>
        <p className="hero-sub">
          Discover, explore & book tickets for cricket, football, kabaddi, and more —
          all in one place.
        </p>
        <div className="hero-cta">
          <a href="#events" className="btn btn-primary btn-lg">Explore Events</a>
          <a href="#featured" className="btn btn-outline btn-lg">Featured Matches</a>
        </div>
        {stats && (
          <div className="hero-stats">
            <div className="hero-stat"><span>{stats.totalEvents}+</span><em>Events</em></div>
            <div className="hero-stat"><span>{stats.cities}</span><em>Cities</em></div>
            <div className="hero-stat"><span>{stats.sports}</span><em>Sports</em></div>
            <div className="hero-stat"><span>{stats.featuredEvents}</span><em>Featured</em></div>
          </div>
        )}
      </div>
    </section>
  );
}
