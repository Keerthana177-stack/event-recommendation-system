import React from 'react';
import EventCard from './EventCard';
import './EventGrid.css';

function SkeletonCard() {
  return (
    <div className="skeleton-card">
      <div className="skeleton" style={{ height: 180 }} />
      <div style={{ padding: 16, display: 'flex', flexDirection: 'column', gap: 10 }}>
        <div className="skeleton" style={{ height: 12, width: '40%' }} />
        <div className="skeleton" style={{ height: 16, width: '90%' }} />
        <div className="skeleton" style={{ height: 14, width: '60%' }} />
        <div className="skeleton" style={{ height: 4 }} />
        <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 4 }}>
          <div className="skeleton" style={{ height: 28, width: '35%' }} />
          <div className="skeleton" style={{ height: 32, width: '30%', borderRadius: 8 }} />
        </div>
      </div>
    </div>
  );
}

export default function EventGrid({ events, loading, view, onSelect, onBook }) {
  if (loading) {
    return (
      <div className={view === 'grid' ? 'event-grid' : 'event-list'}>
        {Array.from({ length: view === 'grid' ? 6 : 4 }).map((_, i) => (
          <SkeletonCard key={i} />
        ))}
      </div>
    );
  }

  if (!events.length) {
    return (
      <div className="no-events">
        <div className="no-events-icon">🔍</div>
        <h3>No events found</h3>
        <p>Try adjusting your filters or search query.</p>
      </div>
    );
  }

  return (
    <div className={view === 'grid' ? 'event-grid' : 'event-list'}>
      {events.map((event, i) => (
        <div key={event.id} style={{ animationDelay: `${i * 0.05}s` }}>
          <EventCard
            event={event}
            onSelect={onSelect}
            onBook={onBook}
            listView={view === 'list'}
          />
        </div>
      ))}
    </div>
  );
}
