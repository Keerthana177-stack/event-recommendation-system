import React, { useState, useEffect } from 'react';
import './BookingModal.css';

// ─── QR CODE (pure SVG, no library) ──────────────────────────────────────────
function QRCode({ value, size = 160 }) {
  const cells = 21;
  const cellSize = size / cells;
  const seed = value.split('').reduce((a, c) => a + c.charCodeAt(0), 0);
  const rand = (i) => ((seed * 9301 + i * 49297) % 233280) / 233280;
  const modules = Array.from({ length: cells }, (_, r) =>
    Array.from({ length: cells }, (_, c) => {
      if ((r < 7 && c < 7) || (r < 7 && c >= cells - 7) || (r >= cells - 7 && c < 7)) return true;
      if (r === 6 || c === 6) return (r + c) % 2 === 0;
      return rand(r * cells + c + seed) > 0.5;
    })
  );
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} style={{ display: 'block', borderRadius: 10 }}>
      <rect width={size} height={size} fill="white" rx="10" />
      {modules.map((row, r) => row.map((on, c) => on ? (
        <rect key={`${r}-${c}`} x={c * cellSize + 1} y={r * cellSize + 1}
          width={cellSize - 1} height={cellSize - 1} fill="#111" rx="1" />
      ) : null))}
      <rect x={size/2-16} y={size/2-16} width={32} height={32} fill="white" rx={5} />
      <text x={size/2} y={size/2+8} textAnchor="middle" fontSize="20" fill="#ff4d00">⚡</text>
    </svg>
  );
}

// ─── STEP BAR ─────────────────────────────────────────────────────────────────
function StepBar({ step }) {
  const steps = ['Details', 'Payment', 'Confirm'];
  return (
    <div className="step-bar">
      {steps.map((s, i) => (
        <React.Fragment key={s}>
          <div className={`step-item ${step > i ? 'done' : step === i ? 'active' : ''}`}>
            <div className="step-circle">{step > i ? '✓' : i + 1}</div>
            <span>{s}</span>
          </div>
          {i < steps.length - 1 && <div className={`step-line ${step > i ? 'done' : ''}`} />}
        </React.Fragment>
      ))}
    </div>
  );
}

// ─── STEP 1: DETAILS ──────────────────────────────────────────────────────────
function StepDetails({ event, form, setForm, errors, onNext, onClose }) {
  const avail = event.seats - event.bookedSeats;
  const total = form.seats * event.price + form.seats * 30;
  return (
    <>
      <div className="bm-avail">
        <span>🎟 {avail} seats available</span>
        <span>₹{event.price.toLocaleString()} / ticket</span>
      </div>
      <div className="bm-field">
        <label>Full Name *</label>
        <input className={`input ${errors.userName ? 'input-error' : ''}`} placeholder="Your full name"
          value={form.userName} onChange={e => setForm(f => ({ ...f, userName: e.target.value }))} />
        {errors.userName && <span className="field-error">{errors.userName}</span>}
      </div>
      <div className="bm-field">
        <label>Email Address *</label>
        <input className={`input ${errors.email ? 'input-error' : ''}`} type="email" placeholder="you@example.com"
          value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} />
        {errors.email && <span className="field-error">{errors.email}</span>}
      </div>
      <div className="bm-field">
        <label>Phone Number *</label>
        <input className={`input ${errors.phone ? 'input-error' : ''}`} type="tel" placeholder="+91 98765 43210"
          value={form.phone} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} />
        {errors.phone && <span className="field-error">{errors.phone}</span>}
      </div>
      <div className="bm-field">
        <label>Number of Seats *</label>
        <div className="seats-control">
          <button className="seat-btn" onClick={() => setForm(f => ({ ...f, seats: Math.max(1, f.seats - 1) }))}>−</button>
          <span className="seat-count">{form.seats}</span>
          <button className="seat-btn" onClick={() => setForm(f => ({ ...f, seats: Math.min(Math.min(avail, 10), f.seats + 1) }))}>+</button>
          <span className="seat-max">Max {Math.min(avail, 10)}</span>
        </div>
        {errors.seats && <span className="field-error">{errors.seats}</span>}
      </div>
      <div className="bm-summary">
        <div className="bm-summary-row"><span>Price per ticket</span><span>₹{event.price.toLocaleString()}</span></div>
        <div className="bm-summary-row"><span>Seats × {form.seats}</span><span>₹{(event.price * form.seats).toLocaleString()}</span></div>
        <div className="bm-summary-row"><span>Convenience fee</span><span>₹{(form.seats * 30).toLocaleString()}</span></div>
        <div className="bm-summary-row bm-total">
          <span>Total Payable</span>
          <span style={{ fontFamily: 'var(--font-display)', fontSize: 28, color: 'var(--accent)' }}>₹{total.toLocaleString()}</span>
        </div>
      </div>
      <div className="bm-actions">
        <button className="btn btn-outline" onClick={onClose}>Cancel</button>
        <button className="btn btn-primary btn-lg" onClick={onNext}>Proceed to Payment →</button>
      </div>
    </>
  );
}

// ─── STEP 2: PAYMENT ──────────────────────────────────────────────────────────
function StepPayment({ event, form, setForm, onPaid, onBack }) {
  const [method, setMethod] = useState(form.paymentMethod || '');
  const [upiId, setUpiId] = useState('');
  const [upiError, setUpiError] = useState('');
  const [cardData, setCardData] = useState({ number: '', name: '', expiry: '', cvv: '' });
  const [cardErrors, setCardErrors] = useState({});
  const [bank, setBank] = useState('');
  const total = form.seats * event.price + form.seats * 30;

  const paymentMethods = [
    { id: 'qr',         icon: '⬛', label: 'Scan QR Code',         sub: 'Pay via any UPI app' },
    { id: 'upi',        icon: '📱', label: 'UPI ID',               sub: 'GPay, PhonePe, Paytm, BHIM' },
    { id: 'card',       icon: '💳', label: 'Debit / Credit Card',  sub: 'Visa, Mastercard, RuPay' },
    { id: 'netbanking', icon: '🏦', label: 'Net Banking',          sub: 'All major Indian banks' },
  ];

  const formatCard   = v => v.replace(/\D/g,'').slice(0,16).replace(/(.{4})/g,'$1 ').trim();
  const formatExpiry = v => { const d = v.replace(/\D/g,'').slice(0,4); return d.length > 2 ? d.slice(0,2)+'/'+d.slice(2) : d; };

  const handlePay = () => {
    if (!method) return;
    if (method === 'upi') {
      if (!upiId.match(/^[\w.\-]+@[\w]+$/)) { setUpiError('Enter valid UPI ID  e.g. name@upi'); return; }
    }
    if (method === 'card') {
      const errs = {};
      if (cardData.number.replace(/\s/g,'').length < 16) errs.number = 'Enter valid 16-digit card number';
      if (!cardData.name.trim()) errs.name = 'Cardholder name required';
      if (!cardData.expiry.match(/^\d{2}\/\d{2}$/)) errs.expiry = 'Format: MM/YY';
      if (cardData.cvv.length < 3) errs.cvv = 'Enter 3-digit CVV';
      if (Object.keys(errs).length) { setCardErrors(errs); return; }
    }
    if (method === 'netbanking' && !bank) return;
    setForm(f => ({ ...f, paymentMethod: method }));
    onPaid();
  };

  return (
    <>
      <div className="pay-total-banner">
        <span>Amount to Pay</span>
        <span className="pay-total-amt">₹{total.toLocaleString()}</span>
      </div>

      <div className="pay-methods">
        {paymentMethods.map(m => (
          <button key={m.id} className={`pay-method-btn ${method === m.id ? 'active' : ''}`}
            onClick={() => { setMethod(m.id); setUpiError(''); setCardErrors({}); }}>
            <span className="pay-method-icon">{m.icon}</span>
            <div className="pay-method-info">
              <span className="pay-method-label">{m.label}</span>
              <span className="pay-method-sub">{m.sub}</span>
            </div>
            <div className={`pay-radio ${method === m.id ? 'checked' : ''}`} />
          </button>
        ))}
      </div>

      {/* QR */}
      {method === 'qr' && (
        <div className="pay-qr-box">
          <p className="pay-qr-title">Scan with any UPI App</p>
          <div className="pay-qr-wrap">
            <QRCode value={`upi://pay?pa=sportspulse@upi&pn=SportsPulse&am=${total}&tn=Ticket`} size={180} />
            <div className="pay-qr-shine" />
          </div>
          <div className="pay-qr-apps">
            {['GPay','PhonePe','Paytm','BHIM','Amazon Pay'].map(a => (
              <span key={a} className="pay-qr-app">{a}</span>
            ))}
          </div>
          <div className="pay-qr-details">
            <div>UPI ID: <strong>sportspulse@upi</strong></div>
            <div className="pay-qr-amount">₹{total.toLocaleString()}</div>
          </div>
          <div className="pay-qr-note">⚠️ Complete payment in your UPI app, then click "I've Paid"</div>
        </div>
      )}

      {/* UPI ID */}
      {method === 'upi' && (
        <div className="pay-upi-box">
          <div className="bm-field">
            <label>Enter Your UPI ID</label>
            <input className={`input ${upiError ? 'input-error' : ''}`}
              placeholder="yourname@upi  or  9876543210@paytm"
              value={upiId} onChange={e => { setUpiId(e.target.value); setUpiError(''); }} />
            {upiError && <span className="field-error">{upiError}</span>}
          </div>
          <div className="upi-apps-row">
            {[{n:'Google Pay',c:'#4285F4',e:'🔵'},{n:'PhonePe',c:'#6739B7',e:'🟣'},{n:'Paytm',c:'#00BAF2',e:'🔷'},{n:'BHIM',c:'#FF6B00',e:'🟠'}].map(a=>(
              <div key={a.n} className="upi-app-chip" style={{ borderColor: a.c+'66' }}>
                <span>{a.e}</span><span>{a.n}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Card */}
      {method === 'card' && (
        <div className="pay-card-box">
          <div className="card-preview">
            <div className="card-preview-top">
              <span className="card-chip">▬▬</span>
              <span className="card-brand">💳</span>
            </div>
            <div className="card-preview-num">{cardData.number || '•••• •••• •••• ••••'}</div>
            <div className="card-preview-bottom">
              <div><div className="card-field-label">Card Holder</div><div>{cardData.name || 'YOUR NAME'}</div></div>
              <div><div className="card-field-label">Expires</div><div>{cardData.expiry || 'MM/YY'}</div></div>
            </div>
          </div>
          <div className="bm-field">
            <label>Card Number</label>
            <input className={`input ${cardErrors.number?'input-error':''}`} placeholder="1234 5678 9012 3456"
              maxLength={19} value={cardData.number}
              onChange={e => setCardData(d => ({ ...d, number: formatCard(e.target.value) }))} />
            {cardErrors.number && <span className="field-error">{cardErrors.number}</span>}
          </div>
          <div className="bm-field">
            <label>Cardholder Name</label>
            <input className={`input ${cardErrors.name?'input-error':''}`} placeholder="As printed on card"
              value={cardData.name} onChange={e => setCardData(d => ({ ...d, name: e.target.value.toUpperCase() }))} />
            {cardErrors.name && <span className="field-error">{cardErrors.name}</span>}
          </div>
          <div style={{ display:'flex', gap:12 }}>
            <div className="bm-field" style={{ flex:1 }}>
              <label>Expiry Date</label>
              <input className={`input ${cardErrors.expiry?'input-error':''}`} placeholder="MM/YY" maxLength={5}
                value={cardData.expiry} onChange={e => setCardData(d => ({ ...d, expiry: formatExpiry(e.target.value) }))} />
              {cardErrors.expiry && <span className="field-error">{cardErrors.expiry}</span>}
            </div>
            <div className="bm-field" style={{ flex:1 }}>
              <label>CVV</label>
              <input className={`input ${cardErrors.cvv?'input-error':''}`} placeholder="•••" maxLength={3}
                type="password" value={cardData.cvv}
                onChange={e => setCardData(d => ({ ...d, cvv: e.target.value.replace(/\D/g,'') }))} />
              {cardErrors.cvv && <span className="field-error">{cardErrors.cvv}</span>}
            </div>
          </div>
          <div className="card-secure-note">🔒 Your card details are encrypted and secure</div>
        </div>
      )}

      {/* Net Banking */}
      {method === 'netbanking' && (
        <div className="pay-nb-box">
          <div className="bm-field">
            <label>Select Your Bank</label>
            <select className="select" value={bank} onChange={e => setBank(e.target.value)}>
              <option value="">-- Choose Bank --</option>
              {['SBI','HDFC Bank','ICICI Bank','Axis Bank','Kotak Mahindra','Bank of Baroda','PNB','Canara Bank','Union Bank','Yes Bank','IndusInd Bank','IDFC First Bank'].map(b=>(
                <option key={b} value={b}>{b}</option>
              ))}
            </select>
          </div>
          {bank && (
            <div className="nb-redirect-note">
              🏦 You'll be securely redirected to <strong>{bank}</strong> net banking portal to complete payment.
            </div>
          )}
        </div>
      )}

      <div className="bm-actions">
        <button className="btn btn-outline" onClick={onBack}>← Back</button>
        <button className="btn btn-primary btn-lg" onClick={handlePay}
          disabled={!method || (method === 'netbanking' && !bank)}>
          {method === 'qr' ? "✅ I've Paid" : `💳 Pay ₹${total.toLocaleString()}`}
        </button>
      </div>
    </>
  );
}

// ─── STEP 3: CONFIRMATION ─────────────────────────────────────────────────────
function StepConfirm({ event, form, bookingId, onClose }) {
  const [processing, setProcessing] = useState(true);
  const [procStep, setProcStep] = useState(0);
  const total = form.seats * event.price + form.seats * 30;
  const procSteps = ['Verifying payment…', 'Reserving your seats…', 'Generating e-ticket…'];

  useEffect(() => {
    const timers = procSteps.map((_, i) => setTimeout(() => setProcStep(i + 1), (i + 1) * 700));
    const done = setTimeout(() => setProcessing(false), 2400);
    return () => { timers.forEach(clearTimeout); clearTimeout(done); };
  }, []);

  if (processing) return (
    <div className="confirm-processing">
      <div className="processing-ring">
        <div className="processing-spinner" />
        <div className="processing-inner">⚡</div>
      </div>
      <h3>Processing Payment</h3>
      <p>Please wait, do not close this window</p>
      <div className="processing-steps">
        {procSteps.map((s, i) => (
          <div key={s} className={`proc-step ${procStep > i ? 'done' : procStep === i ? 'active' : ''}`}>
            <span className="proc-icon">{procStep > i ? '✓' : '○'}</span>
            <span>{s}</span>
          </div>
        ))}
      </div>
    </div>
  );

  return (
    <div className="confirm-success">
      <div className="confirm-tick-wrap">
        <div className="confirm-tick">✓</div>
      </div>
      <h3>Booking Confirmed! 🎉</h3>
      <p>Your e-ticket is ready. Have a great time!</p>

      <div className="confirm-ticket">
        <div className="ticket-header">
          <span className="ticket-brand">⚡ SPORTSPULSE</span>
          <span className="ticket-id">#{bookingId}</span>
        </div>
        <div className="ticket-perf"><span /><span className="ticket-hole" /><span /></div>
        <div className="ticket-body">
          <div className="ticket-event-name">{event.title}</div>
          <div className="ticket-info-grid">
            <div className="ticket-info-item"><span>📍 Venue</span><strong>{event.venue}, {event.city}</strong></div>
            <div className="ticket-info-item"><span>📅 Date</span><strong>{event.date}</strong></div>
            <div className="ticket-info-item"><span>🕐 Time</span><strong>{event.time}</strong></div>
            <div className="ticket-info-item"><span>🎟 Seats</span><strong>{form.seats}</strong></div>
            <div className="ticket-info-item"><span>👤 Name</span><strong>{form.userName}</strong></div>
            <div className="ticket-info-item"><span>💳 Paid via</span><strong style={{textTransform:'capitalize'}}>{form.paymentMethod}</strong></div>
          </div>
          <div className="ticket-total-row">
            <span>Total Paid</span>
            <span className="ticket-total-amt">₹{total.toLocaleString()}</span>
          </div>
        </div>
        <div className="ticket-perf"><span /><span className="ticket-hole" /><span /></div>
        <div className="ticket-qr-section">
          <QRCode value={bookingId + event.id} size={96} />
          <div className="ticket-qr-text">
            <strong>Entry QR Code</strong>
            <span>Show this at the venue entrance</span>
          </div>
        </div>
      </div>

      <div className="confirm-actions">
        <button className="btn btn-outline" onClick={() => window.print()}>🖨 Print Ticket</button>
        <button className="btn btn-primary btn-lg" onClick={onClose}>🎉 Done</button>
      </div>
    </div>
  );
}

// ─── MAIN EXPORT ──────────────────────────────────────────────────────────────
export default function BookingModal({ event, onClose, onBook }) {
  const [step, setStep] = useState(0);
  const [form, setForm] = useState({ userName: '', email: '', phone: '', seats: 1, paymentMethod: '' });
  const [errors, setErrors] = useState({});
  const [bookingId, setBookingId] = useState('');

  useEffect(() => {
    const handler = e => { if (e.key === 'Escape' && step < 2) onClose(); };
    window.addEventListener('keydown', handler);
    document.body.style.overflow = 'hidden';
    return () => { window.removeEventListener('keydown', handler); document.body.style.overflow = ''; };
  }, [onClose, step]);

  const avail = event.seats - event.bookedSeats;

  const validateStep0 = () => {
    const errs = {};
    if (!form.userName.trim()) errs.userName = 'Name is required';
    if (!form.email.trim() || !/\S+@\S+\.\S+/.test(form.email)) errs.email = 'Valid email required';
    if (!form.phone.trim() || form.phone.replace(/\D/g,'').length < 10) errs.phone = 'Enter valid 10-digit phone';
    if (form.seats < 1 || form.seats > Math.min(avail, 10)) errs.seats = `Choose 1–${Math.min(avail,10)} seats`;
    return errs;
  };

  const handleNext = () => {
    const errs = validateStep0();
    if (Object.keys(errs).length) { setErrors(errs); return; }
    setErrors({});
    setStep(1);
  };

  const handlePaid = async () => {
    const id = 'BK' + Math.random().toString(36).substr(2,8).toUpperCase();
    setBookingId(id);
    setStep(2);
    try { await onBook({ eventId: event.id, userName: form.userName, email: form.email, seats: form.seats }); } catch(_) {}
  };

  const titles = ['Book Tickets', 'Choose Payment', 'Your E-Ticket'];

  return (
    <div className="modal-backdrop" onClick={step < 2 ? onClose : undefined}>
      <div className="modal-box booking-modal" onClick={e => e.stopPropagation()}>
        <div className="bm-header">
          <div style={{ flex:1, minWidth:0 }}>
            <div className="bm-label">{titles[step]}</div>
            <h3 className="bm-title">{event.title}</h3>
            <div className="bm-meta">📍 {event.venue}, {event.city} &nbsp;|&nbsp; 📅 {event.date} &nbsp;|&nbsp; 🕐 {event.time}</div>
          </div>
          {step < 2 && <button className="bm-close" onClick={onClose}>✕</button>}
        </div>
        <div style={{ padding: '4px 24px 0' }}>
          <StepBar step={step} />
        </div>
        <div className="bm-body">
          {step === 0 && <StepDetails event={event} form={form} setForm={setForm} errors={errors} onNext={handleNext} onClose={onClose} />}
          {step === 1 && <StepPayment event={event} form={form} setForm={setForm} onPaid={handlePaid} onBack={() => setStep(0)} />}
          {step === 2 && <StepConfirm event={event} form={form} bookingId={bookingId} onClose={onClose} />}
        </div>
      </div>
    </div>
  );
}
