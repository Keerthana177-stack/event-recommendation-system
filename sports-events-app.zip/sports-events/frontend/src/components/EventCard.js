import React from 'react';
import './EventCard.css';

const SPORT_COLORS = {
  Cricket: '#ff4d00', Football: '#00c853', Kabaddi: '#ffb400',
  Basketball: '#ff6d00', Tennis: '#00e5ff', Badminton: '#d500f9', Wrestling: '#f44336'
};

function Stars({ rating }) {
  const full = Math.floor(rating);
  const half = rating % 1 >= 0.5;
  return (
    <span className="stars">
      {'★'.repeat(full)}{half ? '½' : ''}{'☆'.repeat(5 - full - (half ? 1 : 0))}
    </span>
  );
}

function AvailBar({ seats, booked }) {
  const pct = Math.round((booked / seats) * 100);
  const color = pct > 85 ? '#f44336' : pct > 60 ? '#ffb400' : '#00c853';
  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '11px', color: 'var(--muted)', marginBottom: 4 }}>
        <span>{seats - booked} seats left</span><span>{pct}% booked</span>
      </div>
      <div className="avail-bar">
        <div className="avail-bar-fill" style={{ width: pct + '%', background: color }} />
      </div>
    </div>
  );
}

export default function EventCard({ event, onSelect, onBook, listView }) {
  const color = SPORT_COLORS[event.sport] || '#ff4d00';
  const dateObj = new Date(event.date);
  const day = dateObj.toLocaleDateString('en-IN', { day: '2-digit' });
  const mon = dateObj.toLocaleDateString('en-IN', { month: 'short' });

  if (listView) {
    return (
      <div className="event-list-item fade-up">
        <div className="eli-date" style={{ borderLeftColor: color }}>
          <span className="eli-day">{day}</span>
          <span className="eli-mon">{mon}</span>
        </div>
        <img src={event.image} alt={event.title} className="eli-img" />
        <div className="eli-info">
          <div className="eli-top">
            <span className="badge" style={{ background: color + '22', color, border: `1px solid ${color}44` }}>{event.sport}</span>
            {event.featured && <span className="badge badge-gold">★ Featured</span>}
            <span className="badge badge-outline">{event.category}</span>
          </div>
          <h3 className="eli-title">{event.title}</h3>
          <div className="eli-meta">
            <span>📍 {event.venue}, {event.city}</span>
            <span>🕐 {event.time}</span>
            <Stars rating={event.rating} />
          </div>
        </div>
        <div className="eli-right">
          <div className="eli-price">₹{event.price.toLocaleString()}</div>
          <button className="btn btn-primary btn-sm" onClick={() => onBook(event)}>Book Now</button>
          <button className="btn btn-outline btn-sm" onClick={() => onSelect(event)}>Details</button>
        </div>
      </div>
    );
  }

  return (
    <div className="event-card fade-up" onClick={() => onSelect(event)}>
      <div className="ec-image-wrap">
        <img src={event.image} alt={event.title} className="ec-image" loading="lazy" />
        <div className="ec-overlay" />
        <div className="ec-badges">
          <span className="badge" style={{ background: color + 'dd', color: 'white' }}>{event.sport}</span>
          {event.featured && <span className="badge badge-gold">★</span>}
        </div>
        <div className="ec-date-badge">
          <span>{day}</span>
          <span>{mon}</span>
        </div>
      </div>
      <div className="ec-body">
        <div className="ec-category">{event.category}</div>
        <h3 className="ec-title">{event.title}</h3>
        <div className="ec-venue">📍 {event.venue}, {event.city}</div>
        <div className="ec-row">
          <Stars rating={event.rating} />
          <span className="ec-time">🕐 {event.time}</span>
        </div>
        <AvailBar seats={event.seats} booked={event.bookedSeats} />
        <div className="ec-footer">
          <div className="ec-price">
            <span className="ec-price-label">From</span>
            <span className="ec-price-val">₹{event.price.toLocaleString()}</span>
          </div>
          <button className="btn btn-primary btn-sm" onClick={(e) => { e.stopPropagation(); onBook(event); }}>
            Book Now
          </button>
        </div>
      </div>
    </div>
  );
}
