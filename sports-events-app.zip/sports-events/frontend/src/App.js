import React, { useState, useEffect, useCallback } from 'react';
import axios from 'axios';
import Header from './components/Header';
import HeroBanner from './components/HeroBanner';
import FilterBar from './components/FilterBar';
import EventGrid from './components/EventGrid';
import EventModal from './components/EventModal';
import BookingModal from './components/BookingModal';
import StatsBar from './components/StatsBar';
import Toast from './components/Toast';
import './App.css';

function App() {
  const [events, setEvents] = useState([]);
  const [filters, setFilters] = useState({ sports: [], cities: [], categories: [] });
  const [activeFilters, setActiveFilters] = useState({ sport: 'All', city: 'All', category: 'All', search: '', sortBy: 'date_asc', minPrice: '', maxPrice: '' });
  const [loading, setLoading] = useState(true);
  const [selectedEvent, setSelectedEvent] = useState(null);
  const [bookingEvent, setBookingEvent] = useState(null);
  const [stats, setStats] = useState(null);
  const [toasts, setToasts] = useState([]);
  const [view, setView] = useState('grid');

  const addToast = useCallback((message, type = 'success') => {
    const id = Date.now();
    setToasts(prev => [...prev, { id, message, type }]);
    setTimeout(() => setToasts(prev => prev.filter(t => t.id !== id)), 4000);
  }, []);

  const fetchEvents = useCallback(async () => {
    setLoading(true);
    try {
      const params = {};
      Object.entries(activeFilters).forEach(([k, v]) => { if (v && v !== 'All') params[k] = v; });
      const { data } = await axios.get('/api/events', { params });
      setEvents(data.data);
    } catch {
      addToast('Failed to load events', 'error');
    } finally {
      setLoading(false);
    }
  }, [activeFilters, addToast]);

  useEffect(() => { fetchEvents(); }, [fetchEvents]);

  useEffect(() => {
    axios.get('/api/filters').then(({ data }) => setFilters(data.data));
    axios.get('/api/stats').then(({ data }) => setStats(data.data));
  }, []);

  const handleBook = async (bookingData) => {
    try {
      const { data } = await axios.post('/api/book', bookingData);
      addToast(`🎉 Booking confirmed! ID: ${data.booking.bookingId}`, 'success');
      setBookingEvent(null);
      fetchEvents();
    } catch (err) {
      addToast(err.response?.data?.message || 'Booking failed', 'error');
    }
  };

  return (
    <div className="app">
      <Header onSearch={(s) => setActiveFilters(f => ({ ...f, search: s }))} />
      <HeroBanner stats={stats} />
      {stats && <StatsBar stats={stats} />}
      <main className="container" style={{ padding: '32px 24px' }}>
        <FilterBar
          filters={filters}
          activeFilters={activeFilters}
          onFilterChange={(key, val) => setActiveFilters(f => ({ ...f, [key]: val }))}
          onReset={() => setActiveFilters({ sport: 'All', city: 'All', category: 'All', search: '', sortBy: 'date_asc', minPrice: '', maxPrice: '' })}
          view={view}
          onViewChange={setView}
          count={events.length}
        />
        <EventGrid
          events={events}
          loading={loading}
          view={view}
          onSelect={setSelectedEvent}
          onBook={setBookingEvent}
        />
      </main>

      {selectedEvent && (
        <EventModal
          event={selectedEvent}
          onClose={() => setSelectedEvent(null)}
          onBook={(e) => { setSelectedEvent(null); setBookingEvent(e); }}
        />
      )}
      {bookingEvent && (
        <BookingModal
          event={bookingEvent}
          onClose={() => setBookingEvent(null)}
          onBook={handleBook}
        />
      )}
      <Toast toasts={toasts} />
    </div>
  );
}

export default App;
