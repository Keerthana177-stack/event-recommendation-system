const express = require("express");
const cors = require("cors");
const { v4: uuidv4 } = require("uuid");

const app = express();
app.use(cors());
app.use(express.json());

// ─── SEED DATA ────────────────────────────────────────────────────────────────
const sportsEvents = [
  // Cricket
  {
    id: uuidv4(), sport: "Cricket", category: "International",
    title: "India vs Australia - Test Series",
    venue: "Wankhede Stadium", city: "Mumbai", country: "India",
    date: "2026-04-05", time: "09:30", price: 1200,
    image: "https://images.unsplash.com/photo-1531415074968-036ba1b575da?w=600",
    description: "The epic Test battle between India and Australia continues with the 2nd Test in Mumbai.",
    tags: ["Test", "India", "Australia"], rating: 4.8, seats: 250, bookedSeats: 180,
    featured: true
  },
  {
    id: uuidv4(), sport: "Cricket", category: "IPL",
    title: "Mumbai Indians vs Chennai Super Kings",
    venue: "DY Patil Stadium", city: "Navi Mumbai", country: "India",
    date: "2026-04-12", time: "19:30", price: 800,
    image: "https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?w=600",
    description: "The biggest rivalry in IPL history. El Clasico of Indian cricket.",
    tags: ["IPL", "T20", "MI", "CSK"], rating: 4.9, seats: 500, bookedSeats: 490,
    featured: true
  },
  {
    id: uuidv4(), sport: "Cricket", category: "Domestic",
    title: "Ranji Trophy Final",
    venue: "M. Chinnaswamy Stadium", city: "Bengaluru", country: "India",
    date: "2026-04-20", time: "09:00", price: 300,
    image: "https://images.unsplash.com/photo-1593341646782-e0b495cff86d?w=600",
    description: "India's premier domestic red-ball competition. The finals are here!",
    tags: ["Ranji", "Domestic", "Red Ball"], rating: 4.2, seats: 300, bookedSeats: 120,
    featured: false
  },
  {
    id: uuidv4(), sport: "Cricket", category: "International",
    title: "India vs England T20I Series",
    venue: "Eden Gardens", city: "Kolkata", country: "India",
    date: "2026-05-01", time: "19:00", price: 900,
    image: "https://images.unsplash.com/photo-1624969862644-791f3dc98b0f?w=600",
    description: "Five-match T20I series between India and England at the iconic Eden Gardens.",
    tags: ["T20I", "India", "England"], rating: 4.7, seats: 600, bookedSeats: 410,
    featured: true
  },

  // Football
  {
    id: uuidv4(), sport: "Football", category: "ISL",
    title: "Mumbai City FC vs ATK Mohun Bagan",
    venue: "Mumbai Football Arena", city: "Mumbai", country: "India",
    date: "2026-04-08", time: "19:30", price: 500,
    image: "https://images.unsplash.com/photo-1552667466-07770ae110d0?w=600",
    description: "ISL Playoff clash between the two most consistent clubs in Indian football.",
    tags: ["ISL", "Playoff", "Mumbai"], rating: 4.5, seats: 200, bookedSeats: 165,
    featured: true
  },
  {
    id: uuidv4(), sport: "Football", category: "International",
    title: "FIFA World Cup Qualifier - India vs Qatar",
    venue: "Salt Lake Stadium", city: "Kolkata", country: "India",
    date: "2026-06-10", time: "18:00", price: 600,
    image: "https://images.unsplash.com/photo-1551958219-acbc630e2914?w=600",
    description: "India's crucial World Cup qualifier against Qatar. Win or go home!",
    tags: ["FIFA", "Qualifier", "International"], rating: 4.6, seats: 450, bookedSeats: 380,
    featured: true
  },
  {
    id: uuidv4(), sport: "Football", category: "Club",
    title: "Durand Cup - Final",
    venue: "Vivekananda Yuba Bharati Krirangan", city: "Kolkata", country: "India",
    date: "2026-04-25", time: "17:00", price: 350,
    image: "https://images.unsplash.com/photo-1574629810360-7efbbe195018?w=600",
    description: "Asia's oldest football tournament concludes with an exciting final.",
    tags: ["Durand", "Cup", "Final"], rating: 4.3, seats: 350, bookedSeats: 200,
    featured: false
  },

  // Kabaddi
  {
    id: uuidv4(), sport: "Kabaddi", category: "PKL",
    title: "Pro Kabaddi League - Patna Pirates vs Jaipur Pink Panthers",
    venue: "Patliputra Sports Complex", city: "Patna", country: "India",
    date: "2026-04-15", time: "20:00", price: 400,
    image: "https://images.unsplash.com/photo-1599058917212-d750089bc07e?w=600",
    description: "Two PKL giants face off in what promises to be a high-intensity raid battle.",
    tags: ["PKL", "Kabaddi", "Playoff"], rating: 4.4, seats: 180, bookedSeats: 140,
    featured: true
  },
  {
    id: uuidv4(), sport: "Kabaddi", category: "PKL",
    title: "PKL Season 11 Final",
    venue: "Tau Devi Lal Indoor Stadium", city: "Panchkula", country: "India",
    date: "2026-05-15", time: "20:30", price: 700,
    image: "https://images.unsplash.com/photo-1587280501635-68a0e82cd5ff?w=600",
    description: "The grand finale of Pro Kabaddi League Season 11. Champions crowned tonight!",
    tags: ["PKL", "Final", "Grand Finale"], rating: 4.8, seats: 280, bookedSeats: 270,
    featured: true
  },

  // Basketball
  {
    id: uuidv4(), sport: "Basketball", category: "NBA India",
    title: "NBA India Games 2026",
    venue: "NSCI Dome", city: "Mumbai", country: "India",
    date: "2026-04-22", time: "19:00", price: 2500,
    image: "https://images.unsplash.com/photo-1546519638405-a9b9a0dcc4b7?w=600",
    description: "NBA comes to India! Two NBA teams compete in an exhibition showdown in Mumbai.",
    tags: ["NBA", "Basketball", "Exhibition"], rating: 4.9, seats: 150, bookedSeats: 148,
    featured: true
  },
  {
    id: uuidv4(), sport: "Basketball", category: "NBL",
    title: "NBL India Championship Final",
    venue: "Karnail Singh Stadium", city: "Delhi", country: "India",
    date: "2026-05-05", time: "18:30", price: 350,
    image: "https://images.unsplash.com/photo-1504450758481-7338eba7524a?w=600",
    description: "National Basketball League India finale. Best domestic teams clash.",
    tags: ["NBL", "Domestic", "Final"], rating: 4.1, seats: 200, bookedSeats: 85,
    featured: false
  },

  // Tennis
  {
    id: uuidv4(), sport: "Tennis", category: "ATP",
    title: "Tata Open Maharashtra",
    venue: "Mhalunge Balewadi Tennis Complex", city: "Pune", country: "India",
    date: "2026-04-03", time: "14:00", price: 1500,
    image: "https://images.unsplash.com/photo-1622163642998-1ea32b0bbc67?w=600",
    description: "India's only ATP 250 tournament. Top world-class players compete in Pune.",
    tags: ["ATP", "250", "Grass"], rating: 4.6, seats: 100, bookedSeats: 80,
    featured: true
  },

  // Badminton
  {
    id: uuidv4(), sport: "Badminton", category: "BWF",
    title: "India Open 2026 - Finals Day",
    venue: "KD Jadhav Indoor Hall", city: "Delhi", country: "India",
    date: "2026-04-19", time: "15:00", price: 800,
    image: "https://images.unsplash.com/photo-1626224583764-f87db24ac4ea?w=600",
    description: "BWF Super 750 India Open reaches its thrilling conclusion. Champions crowned!",
    tags: ["BWF", "Super750", "Finals"], rating: 4.7, seats: 120, bookedSeats: 115,
    featured: true
  },

  // Wrestling
  {
    id: uuidv4(), sport: "Wrestling", category: "National",
    title: "National Wrestling Championship",
    venue: "Indira Gandhi Arena", city: "Delhi", country: "India",
    date: "2026-04-28", time: "10:00", price: 250,
    image: "https://images.unsplash.com/photo-1587280501635-68a0e82cd5ff?w=600",
    description: "India's best wrestlers compete for national glory across all weight categories.",
    tags: ["Wrestling", "National", "Olympic Styles"], rating: 4.0, seats: 400, bookedSeats: 180,
    featured: false
  },
];

// ─── API ROUTES ────────────────────────────────────────────────────────────────

// GET all events with optional filters
app.get("/api/events", (req, res) => {
  let events = [...sportsEvents];
  const { sport, city, category, featured, search, minPrice, maxPrice, sortBy } = req.query;

  if (sport && sport !== "All") events = events.filter(e => e.sport === sport);
  if (city && city !== "All") events = events.filter(e => e.city === city);
  if (category && category !== "All") events = events.filter(e => e.category === category);
  if (featured === "true") events = events.filter(e => e.featured);
  if (search) {
    const q = search.toLowerCase();
    events = events.filter(e =>
      e.title.toLowerCase().includes(q) ||
      e.sport.toLowerCase().includes(q) ||
      e.city.toLowerCase().includes(q) ||
      e.tags.some(t => t.toLowerCase().includes(q))
    );
  }
  if (minPrice) events = events.filter(e => e.price >= Number(minPrice));
  if (maxPrice) events = events.filter(e => e.price <= Number(maxPrice));

  if (sortBy === "price_asc") events.sort((a, b) => a.price - b.price);
  else if (sortBy === "price_desc") events.sort((a, b) => b.price - a.price);
  else if (sortBy === "date_asc") events.sort((a, b) => new Date(a.date) - new Date(b.date));
  else if (sortBy === "rating") events.sort((a, b) => b.rating - a.rating);

  res.json({ success: true, count: events.length, data: events });
});

// GET single event
app.get("/api/events/:id", (req, res) => {
  const event = sportsEvents.find(e => e.id === req.params.id);
  if (!event) return res.status(404).json({ success: false, message: "Event not found" });
  res.json({ success: true, data: event });
});

// GET filter options
app.get("/api/filters", (req, res) => {
  const sports = ["All", ...new Set(sportsEvents.map(e => e.sport))];
  const cities = ["All", ...new Set(sportsEvents.map(e => e.city))];
  const categories = ["All", ...new Set(sportsEvents.map(e => e.category))];
  res.json({ success: true, data: { sports, cities, categories } });
});

// GET recommendations (based on sport)
app.get("/api/recommendations/:sport", (req, res) => {
  const { sport } = req.params;
  const recs = sportsEvents
    .filter(e => e.sport === sport)
    .sort((a, b) => b.rating - a.rating)
    .slice(0, 4);
  res.json({ success: true, data: recs });
});

// POST book event
app.post("/api/book", (req, res) => {
  const { eventId, userName, email, seats } = req.body;
  const event = sportsEvents.find(e => e.id === eventId);
  if (!event) return res.status(404).json({ success: false, message: "Event not found" });
  const available = event.seats - event.bookedSeats;
  if (seats > available) return res.status(400).json({ success: false, message: `Only ${available} seats left` });
  event.bookedSeats += seats;
  res.json({
    success: true,
    booking: {
      bookingId: "BK" + Math.random().toString(36).substr(2, 8).toUpperCase(),
      event: event.title, userName, email, seats,
      totalPrice: event.price * seats,
      status: "Confirmed"
    }
  });
});

// GET stats
app.get("/api/stats", (req, res) => {
  const sportCounts = {};
  sportsEvents.forEach(e => { sportCounts[e.sport] = (sportCounts[e.sport] || 0) + 1; });
  res.json({
    success: true,
    data: {
      totalEvents: sportsEvents.length,
      featuredEvents: sportsEvents.filter(e => e.featured).length,
      cities: new Set(sportsEvents.map(e => e.city)).size,
      sports: new Set(sportsEvents.map(e => e.sport)).size,
      sportBreakdown: sportCounts
    }
  });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`✅ Sports Events API running at http://localhost:${PORT}`));
