# 🏆 SportsPulse — Sports Event Recommendation App

A full-stack sports event discovery and booking platform built with React + Node.js/Express.

## 📸 Features

- 🔍 **Search & Filter** — Search by keyword, filter by sport, city, category, price range
- 🏏 **14+ Events** — Cricket (IPL, Tests, T20I), Football (ISL, FIFA), Kabaddi (PKL), Basketball, Tennis, Badminton, Wrestling
- 📋 **Grid & List Views** — Toggle between card grid and compact list layout
- ⭐ **Ratings & Availability** — Live seat availability bars, ratings for each event
- 🎟 **Booking System** — Multi-seat booking with form validation and confirmation IDs
- 📊 **Stats Dashboard** — Sport breakdowns, city counts, featured event highlights
- 🌟 **Featured Events** — Highlighted marquee matches
- 🔔 **Toast Notifications** — Success/error feedback on bookings
- 🌙 **Dark Theme** — Sleek dark UI with orange accent

---

## 🛠 Tech Stack

| Layer    | Tech                        |
|----------|-----------------------------|
| Frontend | React 18, Axios, CSS        |
| Backend  | Node.js, Express 4, UUID    |
| Fonts    | Bebas Neue + DM Sans        |
| Design   | Custom CSS with CSS Variables |

---

## 📁 Project Structure

```
sports-events/
├── backend/
│   ├── server.js          # Express API server
│   └── package.json
├── frontend/
│   ├── public/
│   │   └── index.html
│   ├── src/
│   │   ├── App.js         # Root component + state management
│   │   ├── index.js       # Entry point
│   │   ├── index.css      # Global styles & design tokens
│   │   └── components/
│   │       ├── Header.js         # Sticky nav + search bar
│   │       ├── HeroBanner.js     # Hero section with animated background
│   │       ├── StatsBar.js       # Sport breakdown ticker
│   │       ├── FilterBar.js      # Filters: sport chips, city, category, price, sort
│   │       ├── EventGrid.js      # Grid/list layout with skeletons
│   │       ├── EventCard.js      # Individual card (grid + list mode)
│   │       ├── EventModal.js     # Full event detail modal
│   │       ├── BookingModal.js   # Ticket booking form
│   │       └── Toast.js          # Notification toasts
│   └── package.json
├── start.sh               # One-click startup script
└── README.md
```

---

## 🚀 Getting Started

### Prerequisites
- **Node.js** v16+ — [Download](https://nodejs.org)
- **npm** v8+

### Option 1: One-Click Script (Mac/Linux)
```bash
chmod +x start.sh
./start.sh
```

### Option 2: Manual Setup

**Step 1 — Install & Start Backend**
```bash
cd backend
npm install
node server.js
# ✅ API running at http://localhost:5000
```

**Step 2 — Install & Start Frontend** *(new terminal)*
```bash
cd frontend
npm install
npm start
# ✅ App opens at http://localhost:3000
```

---

## 🌐 API Endpoints

| Method | Endpoint                        | Description                        |
|--------|---------------------------------|------------------------------------|
| GET    | `/api/events`                   | Get all events (supports filters)  |
| GET    | `/api/events/:id`               | Get single event by ID             |
| GET    | `/api/filters`                  | Get all filter options             |
| GET    | `/api/stats`                    | Get stats and sport breakdown      |
| GET    | `/api/recommendations/:sport`   | Top-rated events for a sport       |
| POST   | `/api/book`                     | Book tickets for an event          |

### Query Parameters for `/api/events`
| Param     | Example           | Description                  |
|-----------|-------------------|------------------------------|
| sport     | `Cricket`         | Filter by sport              |
| city      | `Mumbai`          | Filter by city               |
| category  | `IPL`             | Filter by category           |
| featured  | `true`            | Featured events only         |
| search    | `india`           | Full-text search             |
| minPrice  | `500`             | Minimum ticket price         |
| maxPrice  | `2000`            | Maximum ticket price         |
| sortBy    | `rating`          | Sort: date_asc, price_asc, price_desc, rating |

---

## 🏅 Sports Covered

| Sport      | Events | Leagues/Competitions         |
|------------|--------|------------------------------|
| 🏏 Cricket  | 4      | IPL, Test Series, T20I, Ranji|
| ⚽ Football | 3      | ISL, FIFA Qualifier, Durand  |
| 🤼 Kabaddi  | 2      | Pro Kabaddi League           |
| 🏀 Basketball | 2    | NBA India, NBL India         |
| 🎾 Tennis   | 1      | Tata Open Maharashtra (ATP)  |
| 🏸 Badminton | 1     | India Open BWF Super 750     |
| 🥊 Wrestling | 1     | National Wrestling Championship |

---

## 📝 Booking Flow

1. Browse events → Click any card to see details
2. Click **"Book Now"** to open booking form
3. Enter name, email, and number of seats
4. Review total price summary
5. Click **"Confirm Booking"** — receive a booking ID instantly

---

## 🎨 Customization

- **Add events**: Edit the `sportsEvents` array in `backend/server.js`
- **Change colors**: Edit CSS variables in `frontend/src/index.css`
- **Add sports**: Add entries to `SPORT_COLORS` and `SPORT_ICONS` in the components
- **Connect a real DB**: Replace the in-memory array with MongoDB/PostgreSQL

---

*Built with ❤️ for sports fans across India*
